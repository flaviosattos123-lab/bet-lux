import React from "react";
import { Image } from "@/components/ui/image";

export default function GameCard({ game, onClick }) {
  return (
    <div
      onClick={onClick}
      className="group relative w-full cursor-pointer overflow-hidden rounded-2xl border border-emerald-500/30 bg-gradient-to-b from-zinc-900 to-black shadow-lg shadow-emerald-500/10 transition-all duration-300 hover:scale-[1.03] hover:border-emerald-400/70 hover:shadow-emerald-400/30 active:scale-95"
    >
      <div className="relative aspect-[3/4] w-full overflow-hidden">
        {game.image_url ? (
          <Image
            src={game.image_url}
            alt={game.name}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
            fittingType="fill"
          />
        ) : (
          <div
            className="flex h-full w-full flex-col items-center justify-center gap-2 p-3 text-center"
            style={{ background: game.gradient || "linear-gradient(135deg,#0a3d2c,#000)" }}
          >
            <span className="text-5xl drop-shadow-lg">{game.emoji || "🎮"}</span>
            <span className="font-display text-lg font-extrabold leading-tight text-white drop-shadow">
              {game.name}
            </span>
          </div>
        )}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-60" />
        {game.is_popular && (
          <span className="absolute left-1.5 top-1.5 rounded-full bg-emerald-400 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide text-black shadow">
            🔥 Popular
          </span>
        )}
        {/* Botão Jogar sobreposto */}
        <div className="absolute inset-x-0 bottom-0 flex justify-center pb-2">
          <span className="rounded-lg bg-gradient-to-r from-emerald-400 to-emerald-500 px-4 py-1.5 text-xs font-black text-black shadow-lg shadow-emerald-500/40">
            ▶ JOGAR
          </span>
        </div>
      </div>
      <div className="flex items-center justify-between gap-1 px-2 py-2">
        <span className="truncate text-xs font-bold text-white">{game.name}</span>
        <span className="shrink-0 rounded bg-emerald-500/20 px-1.5 py-0.5 text-[9px] font-semibold text-emerald-300">
          {game.provider}
        </span>
      </div>
    </div>
  );
}