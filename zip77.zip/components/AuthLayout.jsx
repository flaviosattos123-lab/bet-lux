import React from "react";

export default function AuthLayout({ icon: Icon, title, subtitle, footer, children }) {
  return (
    <div className="relative min-h-screen flex items-center justify-center bg-black px-4 py-10 overflow-hidden">
      {/* Glow de fundo */}
      <div className="pointer-events-none absolute -top-32 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-emerald-500/20 blur-[120px]" />
      <div className="pointer-events-none absolute bottom-0 right-0 h-64 w-64 rounded-full bg-emerald-600/10 blur-[100px]" />

      <div className="relative w-full max-w-md">
        {/* Logo / Brand */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-400 to-emerald-600 shadow-lg shadow-emerald-500/30 mb-4">
            <Icon className="w-8 h-8 text-black" aria-hidden="true" />
          </div>
          <h1 className="font-display text-3xl font-extrabold tracking-tight text-white">
            <span className="bg-gradient-to-r from-emerald-300 to-emerald-500 bg-clip-text text-transparent">BET LUX</span>
          </h1>
          {title && <h2 className="mt-3 text-lg font-semibold text-zinc-200">{title}</h2>}
          {subtitle && <p className="text-sm text-zinc-400 mt-1">{subtitle}</p>}
        </div>

        {/* Card */}
        <div className="rounded-3xl border border-emerald-500/20 bg-gradient-to-b from-zinc-900/90 to-black/90 p-7 shadow-2xl shadow-emerald-500/10 backdrop-blur">
          {children}
        </div>

        {footer && (
          <p className="text-center text-sm text-zinc-400 mt-6">{footer}</p>
        )}
      </div>
    </div>
  );
}