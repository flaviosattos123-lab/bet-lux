import React from "react";
import { useToast } from "@/components/ui/use-toast";

export default function ReferralChest() {
  const { toast } = useToast();
  return (
    <button
      onClick={() =>
        toast({
          title: "🎁 Convide um amigo!",
          description: "Ganhe R$30 de bônus + R$50 no primeiro depósito dele.",
        })
      }
      className="fixed bottom-20 right-4 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-amber-400 to-amber-600 text-2xl shadow-xl shadow-amber-500/50 ring-2 ring-amber-300/50 transition hover:scale-110 active:scale-95"
      aria-label="Indique um amigo"
    >
      🧰
    </button>
  );
}