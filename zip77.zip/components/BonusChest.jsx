import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Gift, X } from "lucide-react";

export default function BonusChest() {
  const [open, setOpen] = useState(true);
  const navigate = useNavigate();

  if (!open) return null;

  return (
    <div className="relative overflow-hidden rounded-3xl border border-emerald-400/40 bg-gradient-to-br from-emerald-950 via-black to-emerald-950 p-4 shadow-xl shadow-emerald-500/20 opacity-85">
      <button
        onClick={() => setOpen(false)}
        className="absolute right-3 top-3 z-10 rounded-full bg-black/50 p-1 text-emerald-300 hover:bg-black/80">
        
        <X size={16} />
      </button>
      <div className="flex items-center gap-4">
        <div className="relative flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-4xl shadow-inner">
          🧰
          <span className="absolute -right-1 -top-1 animate-bounce rounded-full bg-emerald-400 px-1.5 py-0.5 text-[10px] font-black text-black">
            +R$50
          </span>
        </div>
        <div className="flex-1">
          <h3 className="font-display text-lg font-extrabold leading-tight text-white">
            Bônus de <span className="text-emerald-400">R$50</span> no 1º depósito!
          </h3>
          <p className="mt-0.5 text-xs text-emerald-200/80">
            Deposite a partir de R$20 e ganhe R$50 extra para jogar.
          </p>
          <button
            onClick={() => navigate("/deposito")}
            className="mt-2 w-full rounded-xl bg-gradient-to-r from-emerald-400 to-emerald-500 py-2 text-sm font-bold text-black shadow-lg shadow-emerald-500/30 transition hover:brightness-110 active:scale-95">
            
            Resgatar bônus
          </button>
        </div>
      </div>
    </div>);

}