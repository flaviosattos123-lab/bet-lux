import React from "react";
import { Image } from "@/components/ui/image";

const BANNER = "https://media.base44.com/images/public/6a9b6dad669e5335d19cf29e/bffcb2916_Gemini_Generated_Image_83jhjc83jhjc83jh.jpg";

export default function HeroBanner() {
  return (
    <div className="overflow-hidden rounded-2xl border border-emerald-400/40 shadow-lg shadow-emerald-500/20">
      <div className="relative aspect-[16/9] w-full">
        <Image
          src={BANNER}
          alt="Bet Lux"
          className="h-full w-full opacity-100"
          fittingType="fill" />
        
      </div>
    </div>);

}