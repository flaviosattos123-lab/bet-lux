import React from "react";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import { Home as HomeIcon, ArrowDownToLine, ArrowUpFromLine, User } from "lucide-react";
import { Image } from "@/components/ui/image";
import ReferralChest from "@/components/ReferralChest";

const LOGO = "https://media.base44.com/images/public/user_6a9b6da8803a67daf96e6213/84ea0d2ba_bcded92a6_ChatGPTImage4desetde202601_42_38.png";

const nav = [
  { path: "/", label: "Início", icon: HomeIcon },
  { path: "/deposito", label: "Depósito", icon: ArrowDownToLine },
  { path: "/saque", label: "Saque", icon: ArrowUpFromLine },
  { path: "/perfil", label: "Perfil", icon: User },
];

export default function Layout() {
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="sticky top-0 z-40 flex items-center justify-between border-b border-emerald-500/20 bg-black/90 px-4 py-2.5 backdrop-blur">
        <div className="flex items-center gap-2">
          <img src={LOGO} alt="Bet Lux" className="h-10 w-10 rounded-full object-cover ring-2 ring-emerald-400/60" />
          <div className="leading-none">
            <span className="font-display text-xl font-black tracking-tight">
              <span className="text-emerald-400">BET</span>{" "}
              <span className="bg-gradient-to-r from-amber-300 to-amber-500 bg-clip-text text-transparent">LUX</span>
            </span>
            <p className="text-[9px] font-medium uppercase tracking-widest text-emerald-300/70">Aposte com inteligência</p>
          </div>
        </div>
        <button
          onClick={() => navigate("/deposito")}
          className="flex items-center gap-1.5 rounded-full border border-emerald-500/40 bg-emerald-500/10 px-3 py-1.5 text-xs font-bold text-emerald-300"
        >
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
          R$ 0,00
        </button>
      </header>

      {/* Content */}
      <main className="mx-auto max-w-md px-4 pb-24 pt-3">
        <Outlet />
      </main>
      <ReferralChest />

      {/* Bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-emerald-500/20 bg-black/95 backdrop-blur">
        <div className="mx-auto flex max-w-md items-center justify-around px-2 py-2">
          {nav.map(({ path, label, icon: Icon }) => {
            const active = location.pathname === path;
            return (
              <button
                key={path}
                onClick={() => navigate(path)}
                className={`flex flex-1 flex-col items-center gap-0.5 rounded-xl py-1.5 transition ${
                  active ? "text-emerald-400" : "text-zinc-500"
                }`}
              >
                <Icon size={20} className={active ? "drop-shadow-[0_0_6px_rgba(52,211,153,0.6)]" : ""} />
                <span className="text-[10px] font-semibold">{label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}