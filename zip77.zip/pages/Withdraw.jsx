import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { ArrowUpFromLine } from "lucide-react";

export default function Withdraw() {
  const [amount, setAmount] = useState("");
  const [cpf, setCpf] = useState("");
  const [pixKey, setPixKey] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  const value = parseFloat(amount) || 0;

  const formatCPF = (v) => {
    const d = v.replace(/\D/g, "").slice(0, 11);
    return d
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
  };

  const submit = async () => {
    if (value <= 0) return toast({ title: "Informe um valor válido", variant: "destructive" });
    if (cpf.replace(/\D/g, "").length !== 11) return toast({ title: "CPF inválido", variant: "destructive" });
    if (!pixKey.trim()) return toast({ title: "Informe sua chave PIX", variant: "destructive" });

    setSubmitting(true);
    try {
      await base44.entities.Transaction.create({
        type: "withdrawal",
        amount: value,
        status: "pending",
        cpf,
        pix_key: pixKey,
      });
      toast({ title: "Saque solicitado!", description: "Em até 30 min o valor cai na sua conta." });
      setAmount("");
      setCpf("");
      setPixKey("");
    } catch {
      toast({ title: "Erro ao solicitar saque", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-2xl font-black text-white">Saque</h1>
        <p className="text-sm text-zinc-400">Rápido e seguro via PIX</p>
      </div>

      <div className="rounded-2xl border border-emerald-500/20 bg-zinc-900/60 p-4 space-y-4">
        <div>
          <label className="text-xs font-semibold uppercase tracking-wide text-emerald-300">Valor do saque</label>
          <div className="mt-2 flex items-center rounded-xl border border-emerald-500/30 bg-black px-3">
            <span className="text-lg font-bold text-emerald-400">R$</span>
            <input
              type="number"
              inputMode="decimal"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0,00"
              className="w-full bg-transparent px-2 py-3 text-lg font-bold text-white placeholder:text-zinc-600 focus:outline-none"
            />
          </div>
        </div>

        <div>
          <label className="text-xs font-semibold uppercase tracking-wide text-emerald-300">CPF</label>
          <input
            value={cpf}
            onChange={(e) => setCpf(formatCPF(e.target.value))}
            placeholder="000.000.000-00"
            className="mt-2 w-full rounded-xl border border-emerald-500/30 bg-black px-3 py-3 text-sm text-white placeholder:text-zinc-600 focus:border-emerald-400/60 focus:outline-none"
          />
        </div>

        <div>
          <label className="text-xs font-semibold uppercase tracking-wide text-emerald-300">Chave PIX</label>
          <input
            value={pixKey}
            onChange={(e) => setPixKey(e.target.value)}
            placeholder="E-mail, telefone, CPF ou chave aleatória"
            className="mt-2 w-full rounded-xl border border-emerald-500/30 bg-black px-3 py-3 text-sm text-white placeholder:text-zinc-600 focus:border-emerald-400/60 focus:outline-none"
          />
        </div>
      </div>

      <button
        onClick={submit}
        disabled={submitting}
        className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-400 to-emerald-500 py-4 text-base font-black text-black shadow-lg shadow-emerald-500/30 transition hover:brightness-110 active:scale-95 disabled:opacity-40"
      >
        <ArrowUpFromLine size={20} />
        {submitting ? "Enviando..." : "Solicitar saque"}
      </button>
      <p className="text-center text-[11px] text-zinc-500">
        Saques processados em até 30 minutos após a confirmação.
      </p>
    </div>
  );
}