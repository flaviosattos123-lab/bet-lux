import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { useNavigate } from "react-router-dom";
import { Shield, Lock, TrendingUp, Headphones, LogOut, ChevronRight } from "lucide-react";

const features = [
  { icon: Shield, label: "Saque Rápido" },
  { icon: Lock, label: "100% Seguro" },
  { icon: TrendingUp, label: "Melhores Odds" },
  { icon: Headphones, label: "Suporte 24H" },
];

export default function Profile() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    base44.auth
      .me()
      .then(setUser)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const logout = async () => {
    await base44.auth.logout();
    window.location.href = "/login";
  };

  return (
    <div className="space-y-5">
      {/* Avatar */}
      <div className="flex flex-col items-center gap-2 rounded-3xl border border-emerald-500/20 bg-gradient-to-b from-emerald-950/50 to-black p-6 text-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 text-3xl font-black text-black shadow-lg shadow-emerald-500/30">
          {loading ? "…" : (user?.full_name || user?.email || "U").charAt(0).toUpperCase()}
        </div>
        <div>
          <h1 className="font-display text-xl font-black text-white">
            {user?.full_name || "Jogador Bet Lux"}
          </h1>
          <p className="text-sm text-zinc-400">{user?.email || "—"}</p>
        </div>
        <div className="mt-1 flex items-center gap-2 rounded-full bg-emerald-500/10 px-4 py-1.5 text-sm font-bold text-emerald-300">
          Saldo: R$ 0,00
        </div>
      </div>

      {/* Features */}
      <div className="grid grid-cols-2 gap-3">
        {features.map(({ icon: Icon, label }) => (
          <div key={label} className="flex items-center gap-2 rounded-2xl border border-emerald-500/20 bg-zinc-900/60 p-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-500/15 text-emerald-400">
              <Icon size={18} />
            </div>
            <span className="text-xs font-bold text-white">{label}</span>
          </div>
        ))}
      </div>

      {/* Menu */}
      <div className="overflow-hidden rounded-2xl border border-emerald-500/20 bg-zinc-900/60">
        {[
          { label: "Histórico de transações", action: () => toast({ title: "Em breve" }) },
          { label: "Meus bônus", action: () => toast({ title: "Em breve" }) },
          { label: "Configurações", action: () => toast({ title: "Em breve" }) },
        ].map((item, i) => (
          <button
            key={i}
            onClick={item.action}
            className="flex w-full items-center justify-between border-b border-emerald-500/10 px-4 py-3.5 text-sm font-medium text-white last:border-0 hover:bg-white/5"
          >
            {item.label}
            <ChevronRight size={16} className="text-zinc-500" />
          </button>
        ))}
      </div>

      <button
        onClick={logout}
        className="flex w-full items-center justify-center gap-2 rounded-xl border border-red-500/30 bg-red-500/10 py-3.5 text-sm font-bold text-red-400 hover:bg-red-500/20"
      >
        <LogOut size={18} /> Sair da conta
      </button>
    </div>
  );
}