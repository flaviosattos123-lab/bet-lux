import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Copy, QrCode, Wallet, ArrowRight } from "lucide-react";

const PIX_CODE = "91c424e2-f0d8-496c-8564-8b888c4d3f1b";
const QR_URL = `https://api.qrserver.com/v1/create-qr-code/?size=240x240&margin=0&data=${encodeURIComponent(PIX_CODE)}`;

export default function Deposit() {
  const [amount, setAmount] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  const value = parseFloat(amount) || 0;
  const bonus = value >= 20 ? 50 : 0;

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(PIX_CODE);
      toast({ title: "Código copiado!", description: "Cole no seu app do banco." });
    } catch {
      toast({ title: "Não foi possível copiar", variant: "destructive" });
    }
  };

  const submit = async () => {
    if (value < 20) {
      toast({ title: "Depósito mínimo de R$20", variant: "destructive" });
      return;
    }
    setSubmitting(true);
    try {
      await base44.entities.Transaction.create({
        type: "deposit",
        amount: value,
        status: "pending",
        bonus_applied: bonus > 0,
      });
      toast({
        title: "Depósito registrado!",
        description: bonus > 0 ? `Bônus de R$50 adicionado 🎉` : "Aguardando confirmação do pagamento.",
      });
      setAmount("");
    } catch (e) {
      toast({ title: "Erro ao registrar depósito", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  const quick = [20, 50, 100, 200];

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-2xl font-black text-white">Depósito</h1>
        <p className="text-sm text-zinc-400">Mínimo de R$20 · via PIX</p>
      </div>

      {/* Valor */}
      <div className="rounded-2xl border border-emerald-500/20 bg-zinc-900/60 p-4">
        <label className="text-xs font-semibold uppercase tracking-wide text-emerald-300">Valor do depósito</label>
        <div className="mt-2 flex items-center rounded-xl border border-emerald-500/30 bg-black px-3">
          <span className="text-lg font-bold text-emerald-400">R$</span>
          <input
            type="number"
            inputMode="decimal"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="20,00"
            className="w-full bg-transparent px-2 py-3 text-lg font-bold text-white placeholder:text-zinc-600 focus:outline-none"
          />
        </div>
        <div className="mt-3 grid grid-cols-4 gap-2">
          {quick.map((v) => (
            <button
              key={v}
              onClick={() => setAmount(String(v))}
              className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 py-1.5 text-xs font-bold text-emerald-300 hover:bg-emerald-500/20"
            >
              R${v}
            </button>
          ))}
        </div>
        {value >= 20 && (
          <div className="mt-3 flex items-center gap-2 rounded-lg bg-amber-400/10 px-3 py-2 text-xs font-semibold text-amber-300">
            🎁 Bônus de R$50 liberado no 1º depósito!
          </div>
        )}
      </div>

      {/* QR + Copia e Cola */}
      <div className="rounded-2xl border border-emerald-500/20 bg-zinc-900/60 p-4">
        <div className="mb-3 flex items-center gap-2 text-emerald-300">
          <QrCode size={18} />
          <h2 className="font-bold">Pague com PIX</h2>
        </div>
        <div className="flex flex-col items-center gap-4">
          <div className="rounded-2xl bg-white p-3 shadow-lg shadow-emerald-500/20">
            <img src={QR_URL} alt="QR Code PIX" className="h-48 w-48" />
          </div>
          <button
            onClick={copyCode}
            className="flex w-full items-center justify-between gap-2 rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-3 text-left transition hover:bg-emerald-500/20"
          >
            <div className="min-w-0">
              <p className="text-[10px] font-semibold uppercase tracking-wide text-emerald-400">Copia e Cola</p>
              <p className="truncate text-xs text-white">{PIX_CODE}</p>
            </div>
            <span className="flex shrink-0 items-center gap-1 rounded-lg bg-emerald-400 px-3 py-2 text-xs font-bold text-black">
              <Copy size={14} /> Copiar
            </span>
          </button>
        </div>
      </div>

      <button
        onClick={submit}
        disabled={submitting || value < 20}
        className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-400 to-emerald-500 py-4 text-base font-black text-black shadow-lg shadow-emerald-500/30 transition hover:brightness-110 active:scale-95 disabled:cursor-not-allowed disabled:opacity-40"
      >
        <Wallet size={20} />
        {submitting ? "Registrando..." : `Depositar R$ ${value.toFixed(2).replace(".", ",")}`}
        {!submitting && value >= 20 && <ArrowRight size={18} />}
      </button>
      <p className="text-center text-[11px] text-zinc-500">
        O saldo cai em instantes após o pagamento confirmado.
      </p>
    </div>
  );
}