import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import GameCard from "@/components/GameCard";
import BonusChest from "@/components/BonusChest";
import HeroBanner from "@/components/HeroBanner";
import { toast } from "@/components/ui/use-toast";
import { Search } from "lucide-react";

export default function Home() {
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");

  useEffect(() => {
    base44.entities.Game.list("order", 100)
      .then(setGames)
      .catch(() => setGames([]))
      .finally(() => setLoading(false));
  }, []);

  const populares = games.filter((g) => g.is_popular);
  const todos = games.filter((g) =>
    g.name.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <HeroBanner />
      <BonusChest />

      {/* Populares */}
      <section>
        <div className="mb-3 flex items-center gap-2">
          <span className="text-xl">🔥</span>
          <h2 className="font-display text-lg font-extrabold text-white">Populares</h2>
          <div className="h-px flex-1 bg-gradient-to-r from-emerald-500/40 to-transparent" />
        </div>
        {loading ? (
          <div className="grid grid-cols-3 gap-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="aspect-[3/4] animate-pulse rounded-2xl bg-zinc-900" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-3">
            {populares.map((g) => (
              <GameCard key={g.id} game={g} onClick={() => toast({ title: "Só pode jogar depois do primeiro depósito", description: "Faça seu primeiro depósito para liberar os jogos." })} />
            ))}
          </div>
        )}
      </section>

      {/* Todos os jogos */}
      <section>
        <div className="mb-3 flex items-center gap-2">
          <span className="text-xl">🎮</span>
          <h2 className="font-display text-lg font-extrabold text-white">Todos os Jogos</h2>
          <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[10px] font-bold text-emerald-300">
            {games.length}
          </span>
          <div className="h-px flex-1 bg-gradient-to-r from-emerald-500/40 to-transparent" />
        </div>

        <div className="relative mb-4">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar jogo..."
            className="w-full rounded-xl border border-emerald-500/20 bg-zinc-900 py-2.5 pl-9 pr-3 text-sm text-white placeholder:text-zinc-500 focus:border-emerald-400/60 focus:outline-none"
          />
        </div>

        {loading ? (
          <div className="grid grid-cols-3 gap-3">
            {Array.from({ length: 12 }).map((_, i) => (
              <div key={i} className="aspect-[3/4] animate-pulse rounded-2xl bg-zinc-900" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-3">
            {todos.map((g) => (
              <GameCard key={g.id} game={g} onClick={() => toast({ title: "Só pode jogar depois do primeiro depósito", description: "Faça seu primeiro depósito para liberar os jogos." })} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}